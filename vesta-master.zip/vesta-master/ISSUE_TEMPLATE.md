### Operating System (OS/VERSION):

Type here, e.g. CentOS 6

### VestaCP Version:

Type here, e.g. 3.14159

### Installed Software (what you got with the installer):

Type here, e.g. php-fpm, apache, nginx, mysql

### Steps to Reproduce:

Type here, e.g. install vesta and type rm -rf / --no-preserve-root

### Related Issues/Forum Threads:

Found anything that might be related to this? It might help us find the cause.

### Other Notes:

Anything else?
